# 화성특례시 당직 플랫폼 — 클라우드 배포 절차

## 1단계. Supabase DB 만들기 (5분)
1. supabase.com 프로젝트 대시보드 → 왼쪽 **SQL Editor** → New query
2. `supabase_schema.sql` 내용 전체 붙여넣기 → **Run** (초록색 Success 확인)

## 2단계. GitHub 저장소 (5분)
1. github.com → New repository (이름 예: `hs-duty-platform`, **Public**)
2. 이 폴더의 파일 전체를 업로드 (웹에서 "uploading an existing file"로 드래그 가능)
   - index.html / scenarios/ / scripts/ / .github/
3. 저장소 Settings → Secrets and variables → **Actions** → New repository secret 2개:
   - `SUPABASE_URL` = https://olyczpgmvuzvpmaabiow.supabase.co
   - `SUPABASE_ANON_KEY` = (anon 키)
4. Actions 탭 → "시나리오 적재" → Run workflow (샘플 5건이 큐에 들어감)
   → 이후 "민원 자동 유입"이 20분마다 1건씩 자동 접수 (PC 꺼도 동작)

## 3단계. Vercel 배포 (5분)
1. vercel.com → GitHub로 로그인 → **Add New → Project** → 위 저장소 Import
2. 설정 그대로 **Deploy** → 1분 후 `https://프로젝트명.vercel.app` 주소 발급

## 4단계. 지도 키 도메인 변경 (배포 주소 확정 후)
1. vworld.kr 마이페이지 → 인증키 관리 → 서비스 URL을 Vercel 주소로 변경
2. juso.go.kr 주소검색 키도 동일하게 재발급/변경
3. **Vercel 주소를 Claude에게 알려주면** domain 파라미터 반영한 최종 빌드 제공

## Cowork 시나리오 추가 방법
- Cowork가 만든 `민원시나리오_*.json`을 저장소 `scenarios/` 폴더에 업로드(커밋)만 하면
  자동으로 큐에 적재되어 순차 접수됩니다.
